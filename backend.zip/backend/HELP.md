# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.16/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.16/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.16/reference/web/servlet.html)
* [Spring Security](https://docs.spring.io/spring-boot/3.5.16/reference/web/spring-security.html)
* [Validation](https://docs.spring.io/spring-boot/3.5.16/reference/io/validation.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/3.5.16/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Flyway Migration](https://docs.spring.io/spring-boot/3.5.16/how-to/data-initialization.html#howto.data-initialization.migration-tool.flyway)
* [PostgresML](https://docs.spring.io/spring-ai/reference/api/embeddings/postgresml-embeddings.html)
* [PGvector Vector Database](https://docs.spring.io/spring-ai/reference/api/vectordbs/pgvector.html)
* [Spring Cloud Gateway Access Control [Enterprise]](https://techdocs.broadcom.com/us/en/vmware-tanzu/spring/spring-cloud-gateway-extensions/1-0-0/scg-extensions/access-control.html)
* [Spring Reactive Web](https://docs.spring.io/spring-boot/3.5.16/reference/web/reactive.html)
* [Spring Web Services](https://docs.spring.io/spring-boot/3.5.16/reference/io/webservices.html)
* [Redis Search and Query Vector Database](https://docs.spring.io/spring-ai/reference/api/vectordbs/redis.html)
* [Spring Data Redis (Access+Driver)](https://docs.spring.io/spring-boot/3.5.16/reference/data/nosql.html#data.nosql.redis)
* [Spring Session for Spring Data Redis](https://docs.spring.io/spring-session/reference/)
* [Spring Data Reactive Redis](https://docs.spring.io/spring-boot/3.5.16/reference/data/nosql.html#data.nosql.redis)
* [Java Mail Sender](https://docs.spring.io/spring-boot/3.5.16/reference/io/email.html)
* [WebSocket](https://docs.spring.io/spring-boot/3.5.16/reference/messaging/websockets.html)
* [Spring for GraphQL](https://docs.spring.io/spring-boot/3.5.16/reference/web/spring-graphql.html)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/3.5.16/reference/actuator/index.html)
* [Docker Compose Support](https://docs.spring.io/spring-boot/3.5.16/reference/features/dev-services.html#features.dev-services.docker-compose)
* [Gateway](https://docs.spring.io/spring-cloud-gateway/reference/spring-cloud-gateway-server-webmvc.html)
* [OAuth2 Authorization Server](https://docs.spring.io/spring-boot/3.5.16/reference/web/spring-security.html#web.security.oauth2.authorization-server)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Building a Reactive RESTful Web Service](https://spring.io/guides/gs/reactive-rest-service/)
* [Producing a SOAP web service](https://spring.io/guides/gs/producing-web-service/)
* [Messaging with Redis](https://spring.io/guides/gs/messaging-redis/)
* [Messaging with Redis](https://spring.io/guides/gs/messaging-redis/)
* [Using WebSocket to build an interactive web application](https://spring.io/guides/gs/messaging-stomp-websocket/)
* [Building a GraphQL service](https://spring.io/guides/gs/graphql-server/)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)

### Docker Compose support
This project contains a Docker Compose file named `compose.yaml`.
In this file, the following services have been defined:

* pgvector: [`pgvector/pgvector:pg16`](https://hub.docker.com/r/pgvector/pgvector)
* redis: [`redis/redis-stack:latest`](https://hub.docker.com/r/redis/redis-stack)

Please review the tags of the used images and set them to the same as you're running in production.

## VMware Tanzu Spring Enterprise Extensions

You have selected to add [Tanzu Spring](https://www.vmware.com/products/app-platform/tanzu-spring) enterprise extensions to your project.
In order to use these enterprise extensions you must have authorized [access to the Spring Enterprise Repository](https://techdocs.broadcom.com/us/en/vmware-tanzu/spring/tanzu-spring/commercial/spring-tanzu/guide-artifact-repository-administrators.html) artifacts with an entitlement to Tanzu Spring.
To learn more about what is included with Tanzu Spring entitlement, check out [enterprise.spring.io](https://enterprise.spring.io/) for more information.

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

